This is the README.txt file for Zombie Hunter, the best new game out there!

Running:
Once you have acquired the .ZIP file, right-click on it and press EXTRACT ALL (IF YOU DON'T, THE CONSEQUENCES WILL BE DIRE!).
After extracting the .ZIP file, open the newly generated folder and navigate past all of the exciting images and straight to the
.EXE file (sometimes labeled Application). Double-click to launch and you're ready to play!

Troubleshooting:
Honestly, it should be a straightforward process, but if you are not so technologically savvy, just make your nerdy friends
install it for you correctly. 

Playing:
As you can already see, this game is very fun. 
Just press space bar to fire, Z to buy lives (for 50 Score, that is), X to double your bullet speed (nothing's free --- 250 Score)
and the Up and Down arrow keys to move Joe, well, Up and Down. That's pretty much it!

Objective:
Beat the zombie army by destroying the Generator, which will result in you winning the day! You can kill Zombies (and other
creatures) to get Score, which you can then use to purchase better upgrades and lives. 

I know nobody reads a README file. 